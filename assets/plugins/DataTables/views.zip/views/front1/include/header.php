
  <div class="topbar clearfix">
    <div class="container">
      <div class="col-lg-12 text-right">
        <div class="social_buttons">
            &nbsp;
        </div>
      </div>
    </div>
    <!-- end container -->
  </div>
  <!-- end topbar -->

  <header class="header bg-patern">
    <div class="container">
      <div class="site-header clearfix">
        <div class="col-lg-6 col-md-6 col-sm-12 title-area">
          <div class="site-title" id="title">
            <a href="<?= base_url()?>" title="">
                <img style="float:left" src="<?= base_url()?>assets/images/logoypi.png" class="img-responsive" width="75">
                <h4>Pendaftaran Siswa Baru<br> <span>YPI Darussalam Cerme <br>Gresik</span></h4>
            </a><br>
          </div>
        </div>
        <!-- title area -->
        <div class="col-lg-6 col-md-6 col-sm-12">
          <div id="nav" class="right">
            <div class="container clearfix">
              <img src="<?= base_url()?>assets/images/logoppdb.png" class="img-responsive pull-right" width="250">
          
            </div>
          </div>
          <!-- nav -->
        </div>
        <!-- title area -->
      </div>
      <!-- site header -->
    </div>
    <!-- end container -->
  </header>
  <!-- end header -->
  