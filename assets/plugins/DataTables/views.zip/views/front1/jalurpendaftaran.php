
    <section id="intro">
    <div class="container">
      <div class="ror">
        <div class="col-md-8 col-md-offset-2">
          <h1>Unggul prestasi luhur budi pekerti</h1>
          <p>Program unggulan, tahfidz Al qur'an<br><br></p>
        </div>
      </div>
    </div>
  </section>
  
  <section>
    <div class="container clearfix">
      <div class="content col-lg-12 col-md-12 col-sm-12 clearfix">

        <div class="clearfix"></div>

        <div class="col-lg-6 col-md-6 col-sm-12">
          <div class="widget" data-effect="slide-bottom">
            <h3 class="title"><i class="fa fa-plus"></i> Pembiasaan</h3>
            <ul class="check">
              <li><a href="#">3s sapa salam salim</a></li>
              <li><a href="#">Sholat dhuha berjamaah</a></li>
              <li><a href="#">Sholat dhuhur berjamaah</a></li>
              <li><a href="#">Hafalan doa sehari2</a></li>
              <li><a href="#">Hafalan asmaul husna</a></li>
              <li><a href="#">Istighosah</a></li>
              <li><a href="#">Hari bahasa</a></li>
            </ul>
          </div>
          <!-- end widget -->
        </div>
        <!-- large-6 -->

        <div class="col-lg-6 col-md-6 col-sm-12">
          <div class="widget" data-effect="slide-right">
            <h3 class="title"><i class="fa fa-puzzle-piece "></i> Extrakulikuler</h3>
            <ul class="check">
              <li><a href="#">Olahraga: Futsal, Bola volly, Renang, Pencak silat,</a></li>
              <li><a href="#">Agama: Banjari, Qosidah, Qiroah, Pildacil, Tahfidz,</a></li>
              <li><a href="#">Paskibra</a></li>
              <li><a href="#">English fun kids</a></li>
              <li><a href="#">Jarimatik</a></li>
              <li><a href="#">Melukis</a></li>
              <li><a href="#">Angklung</a></li>
              <li><a href="#">Drumband</a></li>
              <li><a href="#">Robot hidrolik</a></li>
            </ul>
          </div>
          <!-- end widget -->
        </div>
        <!-- large-6 -->

      </div>
      <!-- end content -->
    </div>
    <!-- end container -->
  </section>
  <!-- end section -->

  <section class="section4 text-center">
    <div class="general-title">
      <h3>Gallery</h3>
      <hr>
    </div>
    <div class="portfolio-wrapper">
      <div id="owl-demo" class="owl-carousel">
        <div class="item">
          <a data-rel="prettyPhoto" href="<?= base_url('uploads/fotoypi/ypi1.jpeg')?>">
              <img style="width: 283px; height: 193px;" class="lazyOwl" src="<?= base_url('uploads/fotoypi/ypi1.jpeg')?>" data-src="<?= base_url('uploads/fotoypi/ypi1.jpeg')?>" alt="">
         </a>
        </div>
        <div class="item">
          <a data-rel="prettyPhoto" href="<?= base_url('uploads/fotoypi/ypi2.jpeg')?>">
            <img style="width: 283px; height: 193px;" class="lazyOwl" src="<?= base_url('uploads/fotoypi/ypi2.jpeg')?>" data-src="<?= base_url('uploads/fotoypi/ypi2.jpeg')?>" alt="">
         </a>
        </div>
        <div class="item">
          <a data-rel="prettyPhoto" href="<?= base_url('uploads/fotoypi/ypi3.jpeg')?>">
            <img style="width: 283px; height: 193px;" class="lazyOwl" src="<?= base_url('uploads/fotoypi/ypi3.jpeg')?>" data-src="<?= base_url('uploads/fotoypi/ypi3.jpeg')?>" alt="">
         </a>
        </div>
        <div class="item">
          <a data-rel="prettyPhoto" href="<?= base_url('uploads/fotoypi/ypi4.jpeg')?>">
            <img style="width: 283px; height: 193px;" class="lazyOwl" src="<?= base_url('uploads/fotoypi/ypi4.jpeg')?>" data-src="<?= base_url('uploads/fotoypi/ypi4.jpeg')?>" alt="">
         </a>
        </div>
        <div class="item">
          <a data-rel="prettyPhoto" href="<?= base_url('uploads/fotoypi/ypi5.jpeg')?>">
            <img style="width: 283px; height: 193px;" class="lazyOwl" src="<?= base_url('uploads/fotoypi/ypi5.jpeg')?>" data-src="<?= base_url('uploads/fotoypi/ypi5.jpeg')?>" alt="">
         </a>
        </div>
        <div class="item">
          <a data-rel="prettyPhoto" href="<?= base_url('uploads/fotoypi/ypi6.jpeg')?>">
            <img style="width: 283px; height: 193px;" class="lazyOwl" src="<?= base_url('uploads/fotoypi/ypi6.jpeg')?>" data-src="<?= base_url('uploads/fotoypi/ypi6.jpeg')?>" alt="">
         </a>
        </div>
        <div class="item">
          <a data-rel="prettyPhoto" href="<?= base_url('uploads/fotoypi/ypi7.jpeg')?>">
            <img style="width: 283px; height: 193px;" class="lazyOwl" src="<?= base_url('uploads/fotoypi/ypi7.jpeg')?>" data-src="<?= base_url('uploads/fotoypi/ypi7.jpeg')?>" alt="">
         </a>
        </div>
        <div class="item">
          <a data-rel="prettyPhoto" href="<?= base_url('uploads/fotoypi/ypi8.jpeg')?>">
            <img style="width: 283px; height: 193px;" class="lazyOwl" src="<?= base_url('uploads/fotoypi/ypi8.jpeg')?>" data-src="<?= base_url('uploads/fotoypi/ypi8.jpeg')?>" alt="">
         </a>
        </div>
        <div class="item">
          <a data-rel="prettyPhoto" href="<?= base_url('uploads/fotoypi/ypi9.jpeg')?>">
            <img style="width: 283px; height: 193px;" class="lazyOwl" src="<?= base_url('uploads/fotoypi/ypi9.jpeg')?>" data-src="<?= base_url('uploads/fotoypi/ypi9.jpeg')?>" alt="">
         </a>
        </div>
        <div class="item">
          <a data-rel="prettyPhoto" href="<?= base_url('uploads/fotoypi/ypi10.jpeg')?>">
            <img style="width: 283px; height: 193px;" class="lazyOwl" src="<?= base_url('uploads/fotoypi/ypi10.jpeg')?>" data-src="<?= base_url('uploads/fotoypi/ypi10.jpeg')?>" alt="">
         </a>
        </div>
      </div>
      <!-- end owl-demo -->
    </div>
    <!-- end portfolio-wrapper -->
  </section>
  <!-- end section1 -->
  
  <section class="section2">
    <div class="container">
      <div class="message text-center">
        <h2 class="big-title">Ayo Segera <span>Daftar</span>!</h2>
    </div>
      <!-- end message -->
    </div>
    <!-- end container -->
  </section>
  
  <section class="section1 text-center bg-patern2">
    <div class="container">
      <div class="general-title">
        <h3>Gelombang Pendaftaran</h3>
        <hr>
      </div>
        <div class="row">
          <?php foreach ($periodependaftaran as $row){
              $diterima=$this->m_pendaftar->count_diterima($row['id_periodedaftar']);
              ?>
        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12" data-effect="slide-bottom">
          <div class="custom-box">
            <div class="servicetitle">
              <h4><?= $row['nmperiodedaftar']?></h4>
              <hr>
            </div>
            <div class="icn-main-container text-center">
                <img src="<?= base_url()?>uploads/gambarperiode/<?= $row['gambar']?>" class="img-responsive">
            </div>
            <p><?= $row['pengumuman']?></p>
            
            <ul class="pricing">
                <li>Kuota : <?= $row['kuota']?></li>
                <li>Tgl. Pendaftaran : <?= tgl_indo($row['tglbuka'],false)?> s/d <?= tgl_indo($row['tgltutup'],false)?></li>
                <li>Tgl. Verifikasi Berkas : <?= tgl_indo($row['tglbukaverifikasi'],false)?> s/d <?= tgl_indo($row['tgltutupverifikasi'],false)?></li>
                <li>Tgl. Pemetaan : <?= tgl_indo($row['tglbukaseleksi'],false)?> s/d <?= tgl_indo($row['tgltutupseleksi'],false)?></li>
                <li>Tgl. Pengumuman : <?= tgl_indo($row['tglbukapengumuman'],false)?> s/d <?= tgl_indo($row['tgltutuppengumuman'],false)?></li>
                
                <?php if($row['filepengumuman']!=''){?>
                <li><a href="<?= base_url()?>uploads/fileperiode/<?= $row['filepengumuman']?>">File Pengumuman</a></li>
                <?php }?>
            </ul>
            <?php 
            
            $tglbuka = new DateTime($row['tglbuka']);
            $tgltutup = new DateTime($row['tgltutup']);
            $now = new DateTime();
            
            //if($periodedaftar['is_buka']=='1')
            if($now<$tgltutup&&$now>=$tglbuka){ ?>
            <a class="btn btn-primary" href="<?= base_url()?>front/daftar/<?= $this->urlencrypt->encode($row['id_periodedaftar'])?>">Daftar Sekarang</a>
            <?php }elseif($diterima['jumlahditerima']>=$row['kuota']){?>
                <div class="alert alert-danger">Kuota penuh</div>
            <?php
            }else{?>
            <div class="alert alert-warning" >Gelombang tutup</div>
            <?php }?>
          </div>
          <!-- end custombox -->
        </div>
        <!-- end col-4 -->
          <?php }?>
      </div>
    </div>
    <!-- end container -->
  </section>
  <!-- end section1 -->
