<script src="<?= base_url()?>assets/theme1/js/marquee.js"></script>
            <div class="container-fluid cm-container-white">
                <h2 style="margin-top:0;">Selamat datang <strong><?= $this->session->userdata('namauser')?></strong>!</h2> 
                <p>Aplikasi ini adalah aplikasi yang digunakan untuk memantau pendaftaran online</p>
            </div>
            <div class="container-fluid">
            </div>